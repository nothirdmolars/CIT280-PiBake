<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home Again, Home Again, Jiga-tee-Jig</title>
</head>
<body>
    <h1>Welcome</h1>
    <p>The name of your fat pig is: <?php echo htmlspecialchars($name); ?>!</p>

    <ul>
        <li>The pig has been painted the following color(s):</li>
        <?php foreach ($colours as $colour): ?>
            <li>   <?php echo htmlspecialchars($colour); ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>