Hi all!  This is the basic result of the Write PHP Like a Pro: Build a PHP MVC Framework From Scratch Udemy course (https://www.udemy.com/php-mvc-from-scratch/learn/v4/content).

It currently has a basic mvc skeleton, with a routing engine, templating engine (twig), and composer integration.  The actual views themselves aren't anything to look at right now, but everythings there to start working on!
